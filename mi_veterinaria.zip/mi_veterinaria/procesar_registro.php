<?php
// Incluir archivo de conexión
require_once 'php/conexion.php';

// Configurar headers para respuesta JSON
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Verificar que sea una petición POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Método no permitido'
    ]);
    exit;
}

try {
    // Obtener datos del formulario
    $nombre = trim($_POST['nombre'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $telefono = trim($_POST['telefono'] ?? '');
    $mascota = trim($_POST['mascota'] ?? '');
    $edad = intval($_POST['edad'] ?? 0);
    $fecha_hora = $_POST['fecha_hora'] ?? '';

    // Validar campos obligatorios
    if (empty($nombre) || empty($email) || empty($telefono) || empty($mascota) || $edad <= 0 || empty($fecha_hora)) {
        echo json_encode([
            'success' => false,
            'message' => 'Todos los campos son obligatorios'
        ]);
        exit;
    }

    // Validar formato de email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode([
            'success' => false,
            'message' => 'El formato del correo electrónico no es válido'
        ]);
        exit;
    }

    // Validar que la fecha no sea en el pasado
    $fecha_seleccionada = new DateTime($fecha_hora);
    $fecha_actual = new DateTime();
    
    if ($fecha_seleccionada <= $fecha_actual) {
        echo json_encode([
            'success' => false,
            'message' => 'La fecha y hora debe ser futura'
        ]);
        exit;
    }

    // Verificar si el email ya existe
    $stmt_check = $conn->prepare("SELECT id_registro FROM registro WHERE correo = ?");
    $stmt_check->bind_param("s", $email);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();
    
    if ($result_check->num_rows > 0) {
        echo json_encode([
            'success' => false,
            'message' => 'Este correo electrónico ya está registrado'
        ]);
        $stmt_check->close();
        exit;
    }
    $stmt_check->close();

    // Preparar consulta SQL para insertar datos
    $stmt = $conn->prepare("INSERT INTO registro (nom_completo, correo, telefono, nom_mascota, eda_mascota, fecha) VALUES (?, ?, ?, ?, ?, ?)");
    
    if (!$stmt) {
        throw new Exception("Error en la preparación de la consulta: " . $conn->error);
    }

    // Vincular parámetros
    $stmt->bind_param("ssssis", $nombre, $email, $telefono, $mascota, $edad, $fecha_hora);
    
    // Ejecutar consulta
    if ($stmt->execute()) {
        $id_registro = $conn->insert_id;
        
        echo json_encode([
            'success' => true,
            'message' => 'Registro exitoso. ¡Cita agendada correctamente!',
            'data' => [
                'id' => $id_registro,
                'nombre' => $nombre,
                'mascota' => $mascota,
                'fecha' => $fecha_hora
            ]
        ]);
    } else {
        throw new Exception("Error al ejecutar la consulta: " . $stmt->error);
    }
    
    $stmt->close();

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error del servidor: ' . $e->getMessage()
    ]);
} finally {
    // Cerrar conexión
    if (isset($conn)) {
        $conn->close();
    }
}
?>