<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "veterinaria";

// Crear conexión
$conn = new mysqli($host, $user, $password, $database);

// Configurar charset para caracteres especiales
$conn->set_charset("utf8");

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Función para cerrar conexión
function cerrarConexion($conexion) {
    $conexion->close();
}
?>