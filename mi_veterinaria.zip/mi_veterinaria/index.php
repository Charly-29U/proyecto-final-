<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Veterinaria Los Casos</title>
  <link rel="stylesheet" href="css/estilos-navbar.css">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

  <!-- Incluir la barra de navegación -->
  <?php include('vista/navbar.html'); ?>

  <section class="herostyle">
    <div class="herodetails">
      <h1><b>Tu mejor amigo siempre <br> en buenas manos</b></h1>
      <p>Nos preocupamos por el bienestar de tu mascota. Somos un equipo de veterinarios altamente capacitados y comprometidos con la salud de tu compañero de cuatro patas.</p>
    </div>
  </section>
  <section class="carousel">
    <img src="img/hoski.jpg" alt="Mascota feliz 1">
    <img src="img/max.jpg" alt="Mascota feliz 2">
    <img src="img/alasca.jpg" alt="Mascota feliz 3">
  </section>
  <footer>
    <p>&copy; 2025 Veterinaria Los Casos. Todos los derechos reservados.</p>
    <div class="social-icons">
      <a href="https://facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
      <a href="https://instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
      <a href="https://twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
      <a href="https://wa.me/1234567890" target="_blank"><i class="fab fa-whatsapp"></i></a>
    </div>
  </footer>

</body>
</html>
