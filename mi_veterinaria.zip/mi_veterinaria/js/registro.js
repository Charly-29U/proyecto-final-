class RegistroVeterinaria {
    constructor() {
        this.apiUrl = 'http://localhost:3000/api';
        this.form = document.getElementById('formulario-registro');
        this.mensaje = document.getElementById('mensaje');
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.setupValidation();
        this.testConnection();
    }

    setupEventListeners() {
        this.form.addEventListener('submit', (e) => this.handleSubmit(e));
        
        // Validación en tiempo real
        const inputs = this.form.querySelectorAll('input');
        inputs.forEach(input => {
            input.addEventListener('blur', () => this.validateField(input));
            input.addEventListener('input', () => this.clearFieldError(input));
        });
    }

    setupValidation() {
        // Configurar fecha mínima (mañana)
        const fechaInput = document.getElementById('fecha');
        const mañana = new Date();
        mañana.setDate(mañana.getDate() + 1);
        fechaInput.min = mañana.toISOString().slice(0, 16);
    }

    async testConnection() {
        try {
            const response = await fetch(`${this.apiUrl}/test`);
            const data = await response.json();
            
            if (data.success) {
                console.log('✅ Conexión con API establecida');
            }
        } catch (error) {
            console.error('❌ Error de conexión con API:', error);
            this.showMessage('Error de conexión con el servidor', 'error');
        }
    }

    validateField(input) {
        const value = input.value.trim();
        const fieldName = input.name;
        let isValid = true;
        let message = '';

        switch (fieldName) {
            case 'nombre':
                if (value.length < 2) {
                    isValid = false;
                    message = 'El nombre debe tener al menos 2 caracteres';
                }
                break;
            
            case 'email':
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(value)) {
                    isValid = false;
                    message = 'Ingresa un email válido';
                }
                break;
            
            case 'telefono':
                const telefonoRegex = /^\d{7,15}$/;
                if (!telefonoRegex.test(value)) {
                    isValid = false;
                    message = 'El teléfono debe tener entre 7 y 15 dígitos';
                }
                break;
            
            case 'mascota':
                if (value.length < 1) {
                    isValid = false;
                    message = 'El nombre de la mascota es requerido';
                }
                break;
            
            case 'edad':
                const edad = parseInt(value);
                if (isNaN(edad) || edad < 0 || edad > 50) {
                    isValid = false;
                    message = 'La edad debe estar entre 0 y 50 años';
                }
                break;
            
            case 'fecha_hora':
                const fechaCita = new Date(value);
                const ahora = new Date();
                if (fechaCita <= ahora) {
                    isValid = false;
                    message = 'La fecha debe ser futura';
                }
                break;
        }

        this.setFieldValidation(input, isValid, message);
        return isValid;
    }

    setFieldValidation(input, isValid, message) {
        const errorElement = input.parentNode.querySelector('.error-message');
        
        if (errorElement) {
            errorElement.remove();
        }

        if (!isValid) {
            input.classList.add('error');
            const errorDiv = document.createElement('div');
            errorDiv.className = 'error-message';
            errorDiv.textContent = message;
            input.parentNode.appendChild(errorDiv);
        } else {
            input.classList.remove('error');
        }
    }

    clearFieldError(input) {
        input.classList.remove('error');
        const errorElement = input.parentNode.querySelector('.error-message');
        if (errorElement) {
            errorElement.remove();
        }
    }

    async handleSubmit(e) {
        e.preventDefault();
        
        // Validar todos los campos
        const inputs = this.form.querySelectorAll('input[required]');
        let isFormValid = true;
        
        inputs.forEach(input => {
            if (!this.validateField(input)) {
                isFormValid = false;
            }
        });

        if (!isFormValid) {
            this.showMessage('Por favor corrige los errores en el formulario', 'error');
            return;
        }

        // Mostrar indicador de carga
        this.showLoading(true);

        try {
            const formData = new FormData(this.form);
            const datos = Object.fromEntries(formData.entries());

            const response = await fetch(`${this.apiUrl}/registro`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(datos)
            });

            const result = await response.json();

            if (result.success) {
                this.showMessage(result.message, 'success');
                this.form.reset();
                this.setupValidation(); // Reconfigurar fecha mínima
            } else {
                if (result.errores && result.errores.length > 0) {
                    this.showMessage(result.errores.join('<br>'), 'error');
                } else {
                    this.showMessage(result.message, 'error');
                }
            }

        } catch (error) {
            console.error('Error:', error);
            this.showMessage('Error de conexión. Inténtalo de nuevo.', 'error');
        } finally {
            this.showLoading(false);
        }
    }

    showMessage(message, type) {
        this.mensaje.innerHTML = `
            <div class="alert alert-${type}">
                <span class="alert-icon">${type === 'success' ? '✅' : '❌'}</span>
                <span class="alert-text">${message}</span>
            </div>
        `;

        // Auto-ocultar después de 5 segundos si es éxito
        if (type === 'success') {
            setTimeout(() => {
                this.mensaje.innerHTML = '';
            }, 5000);
        }
    }

    showLoading(show) {
        const button = this.form.querySelector('button[type="submit"]');
        
        if (show) {
            button.disabled = true;
            button.innerHTML = '<span class="spinner"></span> Registrando...';
        } else {
            button.disabled = false;
            button.innerHTML = 'Registrarse';
        }
    }
}

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    new RegistroVeterinaria();
});