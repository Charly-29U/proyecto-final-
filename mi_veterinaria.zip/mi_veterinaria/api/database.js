const mysql = require('mysql2/promise');
const dbConfig = require('./config');

class Database {
    constructor() {
        this.connection = null;
    }

    async connect() {
        try {
            this.connection = await mysql.createConnection(dbConfig);
            console.log('✅ Conexión exitosa a la base de datos');
            return this.connection;
        } catch (error) {
            console.error('❌ Error de conexión:', error.message);
            throw error;
        }
    }

    async disconnect() {
        if (this.connection) {
            await this.connection.end();
            console.log('🔌 Conexión cerrada');
        }
    }

    async query(sql, params = []) {
        try {
            if (!this.connection) {
                await this.connect();
            }
            const [results] = await this.connection.execute(sql, params);
            return results;
        } catch (error) {
            console.error('❌ Error en consulta:', error.message);
            throw error;
        }
    }

    async insertRegistro(datos) {
        const sql = `
            INSERT INTO registro (nom_completo, correo, telefono, nom_mascota, eda_mascota, fecha) 
            VALUES (?, ?, ?, ?, ?, ?)
        `;
        const params = [
            datos.nombre,
            datos.email,
            datos.telefono,
            datos.mascota,
            datos.edad,
            datos.fecha_hora
        ];
        return await this.query(sql, params);
    }

    async verificarEmailExiste(email) {
        const sql = 'SELECT COUNT(*) as count FROM registro WHERE correo = ?';
        const result = await this.query(sql, [email]);
        return result[0].count > 0;
    }

    async obtenerRegistros() {
        const sql = 'SELECT * FROM registro ORDER BY fecha DESC';
        return await this.query(sql);
    }
}

module.exports = Database;
