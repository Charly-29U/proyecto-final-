const express = require('express');
const cors = require('cors');
const path = require('path');
const Database = require('./database');

const app = express();
const PORT = process.env.PORT || 3000;
const db = new Database();

// Middlewares
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '..')));

// Validaciones
const validarDatos = (datos) => {
    const errores = [];

    if (!datos.nombre || datos.nombre.trim().length < 2) {
        errores.push('El nombre debe tener al menos 2 caracteres');
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!datos.email || !emailRegex.test(datos.email)) {
        errores.push('El email no es válido');
    }

    const telefonoRegex = /^\d{7,15}$/;
    if (!datos.telefono || !telefonoRegex.test(datos.telefono)) {
        errores.push('El teléfono debe tener entre 7 y 15 dígitos');
    }

    if (!datos.mascota || datos.mascota.trim().length < 1) {
        errores.push('El nombre de la mascota es requerido');
    }

    if (!datos.edad || datos.edad < 0 || datos.edad > 50) {
        errores.push('La edad de la mascota debe estar entre 0 y 50 años');
    }

    if (!datos.fecha_hora) {
        errores.push('La fecha y hora son requeridas');
    } else {
        const fechaCita = new Date(datos.fecha_hora);
        const ahora = new Date();
        if (fechaCita <= ahora) {
            errores.push('La fecha de la cita debe ser futura');
        }
    }

    return errores;
};

// Rutas
app.get('/api/test', (req, res) => {
    res.json({
        success: true,
        message: 'API funcionando correctamente',
        timestamp: new Date().toISOString()
    });
});

app.post('/api/registro', async (req, res) => {
    try {
        const datos = req.body;

        const errores = validarDatos(datos);
        if (errores.length > 0) {
            return res.status(400).json({
                success: false,
                message: 'Datos inválidos',
                errores: errores
            });
        }

        const emailExiste = await db.verificarEmailExiste(datos.email);
        if (emailExiste) {
            return res.status(409).json({
                success: false,
                message: 'Este correo electrónico ya está registrado'
            });
        }

        const resultado = await db.insertRegistro(datos);

        res.status(201).json({
            success: true,
            message: '¡Registro exitoso! Te contactaremos pronto.',
            id: resultado.insertId
        });

    } catch (error) {
        console.error('Error en registro:', error);
        res.status(500).json({
            success: false,
            message: 'Error interno del servidor'
        });
    }
});

app.get('/api/registros', async (req, res) => {
    try {
        const registros = await db.obtenerRegistros();
        res.json({
            success: true,
            data: registros
        });
    } catch (error) {
        console.error('Error obteniendo registros:', error);
        res.status(500).json({
            success: false,
            message: 'Error al obtener registros'
        });
    }
});

// Rutas para archivos HTML
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'index.php'));
});

app.get('/registro', (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'vista', 'registro.html'));
});

// Iniciar servidor
app.listen(PORT, () => {
    console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
    console.log(`📝 Formulario disponible en http://localhost:${PORT}/registro`);
});

// Cierre limpio del servidor
process.on('SIGINT', async () => {
    console.log('\n🛑 Cerrando servidor...');
    await db.disconnect();
    process.exit(0);
});
